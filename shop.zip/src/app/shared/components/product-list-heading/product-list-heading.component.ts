import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-list-heading',
  templateUrl: './product-list-heading.component.html',
  styleUrls: ['./product-list-heading.component.scss']
})
export class ProductListHeadingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
