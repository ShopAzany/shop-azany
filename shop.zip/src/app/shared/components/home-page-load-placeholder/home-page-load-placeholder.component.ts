import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-page-load-placeholder',
  templateUrl: './home-page-load-placeholder.component.html',
  styleUrls: ['./home-page-load-placeholder.component.scss']
})
export class HomePageLoadPlaceholderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
