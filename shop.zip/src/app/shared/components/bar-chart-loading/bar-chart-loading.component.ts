import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bar-chart-loading',
  templateUrl: './bar-chart-loading.component.html',
  styleUrls: ['./bar-chart-loading.component.scss']
})
export class BarChartLoadingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
