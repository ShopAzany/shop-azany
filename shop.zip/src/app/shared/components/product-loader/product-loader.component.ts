import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-loader',
  templateUrl: './product-loader.component.html',
  styleUrls: ['./product-loader.component.scss']
})
export class ProductLoaderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
