export class UserBankAccount {
    id: number;
    login_id: number;
    account_name: string;
    account_number: string;
    bank: string;
    branch: string;
    swift_code: string;
    created_at: Date;
    updated_at: Date;
}
