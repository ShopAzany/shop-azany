export class Language {
    constructor (
        name: string
    ) {}
}
